# Handles GitHub API interactions

def get_issues(repo):
    pass

def get_prs(repo):
    pass
