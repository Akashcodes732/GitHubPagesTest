# Builds prompts for summarization

def build_prompt(entry):
    pass
