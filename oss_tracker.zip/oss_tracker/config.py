# Global settings and constants

GITHUB_TOKEN = ''
SLACK_WEBHOOK_URL = ''
