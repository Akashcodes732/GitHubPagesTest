# Cleans and prepares GitHub data

def clean_html(text):
    pass
