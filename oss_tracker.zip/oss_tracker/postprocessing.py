# Filters and organizes summary output

def group_by_label(data):
    pass
