# Sends messages to Slack via webhook

def send_digest_to_slack(summary):
    pass
